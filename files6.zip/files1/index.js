// Track Render Panel — index.js
//
// Notes on the API calls used below:
// - require("premierepro") gives the Premiere DOM API (Project, Sequence, tracks, EncoderManager).
// - require("uxp").storage gives the file-system picker used for the output folder.
// - Track listing uses sequence.getVideoTrackCount()/getVideoTrack(i) and the audio equivalents,
//   which is the documented pattern in Adobe's @adobe/premierepro type definitions.
// - "Selecting" a track for render is implemented by muting every other track, exporting,
//   then restoring the original mute states. Premiere's API does not expose per-clip
//   enable/disable, only per-track mute — see the README for the workaround if you need
//   clip-level (not just track-level) selection.
// - Verify method names against your installed Premiere version's type declarations
//   (npm install -D @adobe/premierepro) since the UXP API surface is still evolving.

const IS_DEMO =
  typeof location !== "undefined" &&
  new URLSearchParams(location.search).get("demo") === "1";

let ppro;
let uxpStorage;
let localFileSystem;
let domains;
let entrypoints;
let os;

if (IS_DEMO) {
  const demo = window.__TRACK_RENDER_DEMO__;
  if (!demo) {
    throw new Error("Demo mode requires demo-shim.js to load before index.js");
  }
  ppro = demo.ppro;
  uxpStorage = demo.uxp.storage;
  localFileSystem = uxpStorage.localFileSystem;
  domains = uxpStorage.domains;
  entrypoints = demo.uxp.entrypoints;
  os = demo.os;
} else {
  ppro = require("premierepro");
  uxpStorage = require("uxp").storage;
  localFileSystem = uxpStorage.localFileSystem;
  domains = uxpStorage.domains;
  entrypoints = require("uxp").entrypoints;
  os = require("os");
}

let project = null;
let sequence = null;
let videoTracks = []; // { track, index, name, type, clipCount }
let audioTracks = [];
let originalMuteState = []; // [{ track, muted }]
let presetPath = null; // selected .epr path, or null = sequence export settings
let exportPresets = []; // { path, name, group }
let outputFolderPath = ""; // last chosen output folder native path
let isScanning = false;
let isLoadingPresets = false;
let jobIdCounter = 0;

function setStatus(message, tone = "ok") {
  const el = document.getElementById("status");
  if (!el) return;
  el.textContent = message;
  el.className = tone === "err" ? "status-err" : tone === "warn" ? "status-warn" : tone === "busy" ? "status-busy" : "status-ok";
}

function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);
  const panel = document.getElementById("panelScroll");
  if (!section) return;
  if (panel) {
    const panelRect = panel.getBoundingClientRect();
    const sectionRect = section.getBoundingClientRect();
    const targetTop = sectionRect.top - panelRect.top + panel.scrollTop - 10;
    panel.scrollTo({ top: Math.max(0, targetTop), behavior: "smooth" });
    return;
  }
  section.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function getDestinationLabel(destination) {
  return destination === "ame" ? "Media Encoder" : "Premiere Pro";
}

function updateDestinationUI(scrollIntoView) {
  const destination = getSelectedDestination();
  const isAme = destination === "ame";
  const label = getDestinationLabel(destination);

  const badge = document.getElementById("destBadge");
  if (badge) {
    badge.textContent = label;
    badge.className = isAme ? "meta-pill dest-badge dest-ame" : "meta-pill dest-badge dest-premiere";
  }

  document.querySelectorAll(".deck-option-premiere, .deck-option-ame").forEach((el) => {
    el.classList.remove("selected");
  });
  const activeOption = document.querySelector(isAme ? ".deck-option-ame" : ".deck-option-premiere");
  if (activeOption) activeOption.classList.add("selected");

  const destHint = document.getElementById("destHint");
  if (destHint) {
    destHint.textContent = isAme
      ? "Selected: Media Encoder — jobs are queued in AME. Open AME and press Start Queue (▶)."
      : "Selected: Premiere Pro — renders immediately inside Premiere.";
  }

  if (scrollIntoView) {
    scrollToSection("destinationSection");
  }
}

function setRenderStatus(state, title, detail) {
  const panel = document.getElementById("renderStatus");
  const titleEl = document.getElementById("renderStatusTitle");
  const detailEl = document.getElementById("renderStatusDetail");
  if (!panel || !titleEl || !detailEl) return;

  if (!state) {
    panel.classList.remove("visible", "state-started", "state-done", "state-failed");
    titleEl.textContent = "";
    detailEl.textContent = "";
    return;
  }

  panel.classList.add("visible");
  panel.classList.remove("state-started", "state-done", "state-failed");
  panel.classList.add(`state-${state}`);
  titleEl.textContent = title || "";
  detailEl.textContent = detail || "";
  scrollToSection("renderStatus");
}

function getTrackKey(kind, index) {
  return `${kind}:${index}`;
}

function readTrackSelection() {
  const checks = document.querySelectorAll(".track-check");
  if (checks.length === 0) return null;
  const selected = new Set();
  checks.forEach((c) => {
    if (c.checked) selected.add(getTrackKey(c.dataset.kind, c.dataset.index));
  });
  return selected;
}

function updateRenderButtonState() {
  const renderBtn = document.getElementById("renderBtn");
  const folderHint = document.getElementById("folderHint");
  if (!renderBtn) return;

  const selectedCount = getSelectedTracks().length;
  const hasFolder = Boolean(outputFolderPath || document.getElementById("outputFolder").value.trim());
  const hasSequence = Boolean(sequence);
  const ready = hasSequence && selectedCount > 0 && hasFolder;

  renderBtn.disabled = !ready;
  renderBtn.title = !hasSequence
    ? "Rescan the sequence first"
    : selectedCount === 0
      ? "Arm at least one track"
      : !hasFolder
        ? "Choose an output folder"
        : "Start render";

  updateReadinessPanel(hasSequence, selectedCount, hasFolder);

  if (folderHint) {
    folderHint.className = "hint" + (hasFolder ? "" : " hint-warn");
    folderHint.textContent = hasFolder
      ? "Output folder ready."
      : "Required — click Browse to choose a save location.";
  }
}

function updateReadinessPanel(hasSequence, selectedCount, hasFolder) {
  const panel = document.getElementById("readinessPanel");
  if (!panel) return;
  setReadyItem("readySequence", hasSequence, "Sequence loaded");
  setReadyItem("readyTracks", selectedCount > 0, `${selectedCount} track(s) armed`);
  setReadyItem("readyFolder", hasFolder, "Output folder chosen");
  panel.classList.toggle("all-ready", hasSequence && selectedCount > 0 && hasFolder);
}

function setReadyItem(id, done, label) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle("done", done);
  el.querySelector(".ready-label").textContent = label;
}

function truncatePath(path, maxLen = 42) {
  if (!path || path.length <= maxLen) return path;
  const parts = path.replace(/\\/g, "/").split("/");
  const file = parts.pop();
  let prefix = parts.join("/");
  while (prefix.length > maxLen - file.length - 4 && parts.length > 1) {
    parts.shift();
    prefix = "…/" + parts.join("/");
  }
  return (prefix ? prefix + "/" : "") + file;
}

function formatFolderDisplay(path) {
  const input = document.getElementById("outputFolder");
  if (!input) return;
  input.value = truncatePath(path);
  input.title = path || "";
}

function updateSelectionSummary() {
  const summary = document.getElementById("selectionSummary");
  if (!summary) return;
  const total = videoTracks.length + audioTracks.length;
  const selected = getSelectedTracks().length;
  if (total === 0) {
    summary.textContent = "No tracks";
    summary.className = "meta-pill";
    return;
  }
  summary.textContent = selected + " / " + total + " armed";
  summary.className = "meta-pill" + (selected === 0 ? " pill-warn" : selected === total ? " pill-ok" : "");
}

function clearSequenceState() {
  project = null;
  sequence = null;
  videoTracks = [];
  audioTracks = [];
}

function getTrackLabel(t) {
  return (t.type === "video" ? "V" : "A") + (t.index + 1);
}

// Unique per track (V1_MyTrack) so duplicate track names never overwrite files.
function buildTrackSuffix(t) {
  return sanitizeFileName(`${getTrackLabel(t)}_${t.name}`);
}

// Adds one row to the persistent job log so the user has a record of what
// was actually submitted — important for the AME destination, where no
// window comes to the front and the panel's one-line status message is the
// only other feedback. Each entry stays visible until the panel reloads.
function setProgress(percent, visible) {
  const wrap = document.getElementById("progressWrap");
  const bar = document.getElementById("progressBar");
  if (!wrap || !bar) return;
  if (!visible) {
    wrap.classList.remove("visible");
    bar.style.width = "0%";
    return;
  }
  wrap.classList.add("visible");
  bar.style.width = Math.min(100, Math.max(0, percent)) + "%";
}

function beginJobLogEntry(name, destination) {
  document.getElementById("activitySection").style.display = "block";
  const log = document.getElementById("jobLog");
  log.classList.add("visible");
  const jobId = "job-" + (++jobIdCounter);
  const entry = document.createElement("div");
  entry.className = "job-entry started";
  entry.dataset.jobId = jobId;
  const time = new Date().toLocaleTimeString();
  const destLabel = destination === "ame" ? "AME queue" : "Premiere render";
  entry.innerHTML =
    '<div class="job-line1">' +
      '<span class="job-name">' + escapeHtml(name) + " — " + escapeHtml(destLabel) + '</span>' +
      '<span class="job-time">' + escapeHtml(time) + '</span>' +
    '</div>' +
    '<div class="job-path">In progress…</div>';
  log.insertBefore(entry, log.firstChild);
  return jobId;
}

function finishJobLogEntry(jobId, { ok, outPath, error }) {
  const entry = document.querySelector(`[data-job-id="${jobId}"]`);
  if (!entry) return;
  entry.className = "job-entry " + (ok ? "ok" : "err");
  const pathLine = entry.querySelector(".job-path");
  if (pathLine) {
    pathLine.textContent = ok ? outPath : "Failed: " + (error || "Unknown error");
  }
}

// Legacy single-shot log row (used when no in-progress entry exists).
function addJobLogEntry({ ok, started, name, destination, outPath, error }) {
  if (started) return beginJobLogEntry(name, destination);
  document.getElementById("activitySection").style.display = "block";
  const log = document.getElementById("jobLog");
  log.classList.add("visible");
  const entry = document.createElement("div");
  entry.className = "job-entry " + (ok ? "ok" : "err");
  const time = new Date().toLocaleTimeString();
  const destLabel = destination === "ame" ? "AME queue" : "Premiere render";
  entry.innerHTML =
    '<div class="job-line1">' +
      '<span class="job-name">' + escapeHtml(name) + " — " + escapeHtml(destLabel) + '</span>' +
      '<span class="job-time">' + escapeHtml(time) + '</span>' +
    '</div>' +
    '<div class="job-path">' + (ok ? escapeHtml(outPath) : "Failed: " + escapeHtml(error || "Unknown error")) + '</div>';
  log.insertBefore(entry, log.firstChild);
}

async function loadSequence() {
  if (isScanning) return;
  isScanning = true;
  const refreshBtn = document.getElementById("refreshBtn");
  const trackList = document.getElementById("trackList");
  if (refreshBtn) refreshBtn.disabled = true;
  if (trackList) trackList.classList.add("loading");

  const previousSelection = readTrackSelection();
  setStatus("Scanning sequence…", "warn");
  try {
    project = await ppro.Project.getActiveProject();
    if (!project) {
      clearSequenceState();
      setStatus("No active project open in Premiere.", "err");
      renderTrackList(null);
      return;
    }
    sequence = await project.getActiveSequence();
    if (!sequence) {
      clearSequenceState();
      setStatus("No active sequence. Open a sequence in the timeline.", "err");
      renderTrackList(null);
      return;
    }

    videoTracks = [];
    audioTracks = [];

    const videoTrackCount = await sequence.getVideoTrackCount();
    for (let i = 0; i < videoTrackCount; i++) {
      const track = await sequence.getVideoTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      videoTracks.push({
        track,
        index: i,
        name: track.name || `V${i + 1}`,
        type: "video",
        clipCount: items ? items.length : 0,
      });
    }

    const audioTrackCount = await sequence.getAudioTrackCount();
    for (let i = 0; i < audioTrackCount; i++) {
      const track = await sequence.getAudioTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      audioTracks.push({
        track,
        index: i,
        name: track.name || `A${i + 1}`,
        type: "audio",
        clipCount: items ? items.length : 0,
      });
    }

    renderTrackList(previousSelection);
    setStatus(`Found ${videoTracks.length} video and ${audioTracks.length} audio track(s).`, "ok");
  } catch (err) {
    clearSequenceState();
    setStatus(`Scan failed: ${err.message || err}`, "err");
    renderTrackList(null);
  } finally {
    isScanning = false;
    if (refreshBtn) refreshBtn.disabled = false;
    if (trackList) trackList.classList.remove("loading");
    updateRenderButtonState();
    updateSelectionSummary();
    // Load presets in background so folder/browse controls stay responsive.
    loadExportPresets().catch((err) => console.error("Preset load failed:", err));
  }
}

function renderTrackList(previousSelection = null) {
  const list = document.getElementById("trackList");
  list.innerHTML = "";
  const all = [...videoTracks, ...audioTracks];
  if (all.length === 0) {
    list.innerHTML = '<div class="channel-empty">No tracks found. Open a sequence and rescan.</div>';
    return;
  }
  all.forEach((t) => {
    const key = getTrackKey(t.type, t.index);
    const checked = previousSelection === null ? true : previousSelection.has(key);
    const row = document.createElement("div");
    row.className = "channel-row" + (checked ? "" : " channel-row--disarmed");
    const idLabel = t.type === "video" ? "V" + (t.index + 1) : "A" + (t.index + 1);
    const idClass = t.type === "video" ? "v" : "a";
    row.innerHTML =
      '<label>' +
        '<input type="checkbox" class="track-check tally-input" data-kind="' + t.type + '" data-index="' + t.index + '"' + (checked ? " checked" : "") + ' />' +
        '<span class="tally"></span>' +
        '<span class="channel-id ' + idClass + '">' + idLabel + '</span>' +
        '<span class="channel-name">' + escapeHtml(t.name) + '</span>' +
        '<span class="channel-count">' + t.clipCount + (t.clipCount === 1 ? ' clip' : ' clips') + '</span>' +
      '</label>';
    list.appendChild(row);
  });
  list.querySelectorAll(".track-check").forEach((input) => {
    input.addEventListener("change", () => {
      input.closest(".channel-row").classList.toggle("channel-row--disarmed", !input.checked);
      updateRenderButtonState();
      updateSelectionSummary();
    });
  });
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function getSelectedTracks() {
  const checks = document.querySelectorAll(".track-check");
  const selected = [];
  checks.forEach((c) => {
    if (!c.checked) return;
    const kind = c.dataset.kind;
    const index = parseInt(c.dataset.index, 10);
    const source = kind === "video" ? videoTracks : audioTracks;
    const found = source.find((t) => t.index === index);
    if (found) selected.push(found);
  });
  return selected;
}

function setAllTracksChecked(checked) {
  document.querySelectorAll(".track-check").forEach((c) => {
    c.checked = checked;
    const row = c.closest(".channel-row");
    if (row) row.classList.toggle("channel-row--disarmed", !checked);
  });
  updateRenderButtonState();
  updateSelectionSummary();
}

async function snapshotMuteState() {
  originalMuteState = [];
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    const muted = await t.track.isMuted();
    originalMuteState.push({ track: t.track, muted });
  }
}

async function restoreMuteState() {
  let restoreErrors = 0;
  for (const entry of originalMuteState) {
    try {
      await entry.track.setMute(entry.muted);
    } catch (err) {
      restoreErrors++;
      console.error("Failed to restore mute state:", err);
    }
  }
  return restoreErrors;
}

// Mutes every track except the ones in keepTracks.
async function isolateTracks(keepTracks) {
  const keepSet = new Set(keepTracks.map((t) => t.track));
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    try {
      await t.track.setMute(!keepSet.has(t.track));
    } catch (err) {
      const label = getTrackLabel(t);
      throw new Error(`Could not mute/unmute ${label}: ${err.message || err}`);
    }
  }
}

async function runExport(manager, exportType, outPath) {
  const ok = await manager.exportSequence(
    sequence,
    exportType,
    outPath,
    presetPath || undefined,
    true
  );
  if (ok === false) {
    throw new Error("Export was rejected by Premiere (exportSequence returned false).");
  }
  return ok;
}

function sanitizeFileName(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, "_");
}

function sanitizeExtension(ext) {
  const cleaned = String(ext || "mp4").trim().replace(/^\./, "").replace(/[^a-zA-Z0-9]/g, "");
  return cleaned || "mp4";
}

function buildOutputPath(folder, baseName, suffix, ext) {
  const name = sanitizeFileName(`${baseName}_${suffix}`);
  return `${folder}/${name}.${sanitizeExtension(ext)}`;
}

function getEntryNativePath(entry) {
  if (!entry) return null;
  if (entry.nativePath) return entry.nativePath;
  if (entry.url) {
    const url = String(entry.url);
    if (url.startsWith("file:")) {
      let path = url.replace(/^file:/, "");
      if (path.startsWith("//")) path = path.slice(2);
      try {
        path = decodeURIComponent(path);
      } catch (err) {
        // keep raw path
      }
      return path;
    }
  }
  return null;
}

function setOutputFolder(path) {
  outputFolderPath = path || "";
  formatFolderDisplay(outputFolderPath);
  updateRenderButtonState();
}

async function chooseOutputFolder() {
  const btn = document.getElementById("chooseFolderBtn");
  if (btn) btn.disabled = true;
  try {
    const pickerOptions = {};
    if (domains && domains.userDocuments) {
      pickerOptions.initialDomain = domains.userDocuments;
    }
    const folder = await localFileSystem.getFolder(pickerOptions);
    if (!folder) return null;
    const path = getEntryNativePath(folder);
    if (!path) {
      setStatus("Folder selected but path could not be read. Try another folder.", "err");
      return null;
    }
    setOutputFolder(path);
    setStatus(`Output folder: ${path}`, "ok");
    return path;
  } catch (err) {
    setStatus(`Folder selection failed: ${err.message || err}`, "err");
    return null;
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function choosePresetFile() {
  try {
    const pickerOptions = { types: ["epr"] };
    if (domains && domains.userDocuments) {
      pickerOptions.initialDomain = domains.userDocuments;
    }
    const file = await localFileSystem.getFileForOpening(pickerOptions);
    if (!file) return null;
    return getEntryNativePath(file);
  } catch (err) {
    setStatus(`Preset selection failed: ${err.message || err}`, "err");
    return null;
  }
}

function toFileUrl(nativePath) {
  const normalized = String(nativePath).replace(/\\/g, "/");
  if (normalized.startsWith("/")) {
    return `file:${normalized}`;
  }
  return `file:/${normalized}`;
}

async function tryGetEntry(fileUrl) {
  try {
    return await localFileSystem.getEntryWithUrl(fileUrl);
  } catch (err) {
    return null;
  }
}

async function tryGetChildFolder(folder, childName) {
  if (!folder || !folder.isFolder) return null;
  try {
    const child = await folder.getEntry(childName);
    return child && child.isFolder ? child : null;
  } catch (err) {
    return null;
  }
}

async function tryGetNestedFolder(folder, segments) {
  let current = folder;
  for (const segment of segments) {
    current = await tryGetChildFolder(current, segment);
    if (!current) return null;
  }
  return current;
}

async function scanFolderForEpr(folder, groupLabel, results, seen, depth = 0) {
  if (!folder || !folder.isFolder || depth > 8) return;
  let entries;
  try {
    entries = await folder.getEntries();
  } catch (err) {
    return;
  }
  for (const entry of entries) {
    if (entry.isFile && entry.name.toLowerCase().endsWith(".epr")) {
      const path = entry.nativePath;
      if (seen.has(path)) continue;
      seen.add(path);
      results.push({
        path,
        name: entry.name.replace(/\.epr$/i, ""),
        group: groupLabel,
      });
    } else if (entry.isFolder) {
      await scanFolderForEpr(entry, groupLabel, results, seen, depth + 1);
    }
  }
}

async function scanApplicationsForPresets(results, seen) {
  const apps = await tryGetEntry("file:/Applications");
  if (!apps || !apps.isFolder) return;

  let entries;
  try {
    entries = await apps.getEntries();
  } catch (err) {
    return;
  }

  for (const entry of entries) {
    if (!entry.isFolder) continue;
    const name = entry.name;
    if (name.startsWith("Adobe Media Encoder")) {
      const presets = await tryGetChildFolder(entry, "Presets");
      if (presets) await scanFolderForEpr(presets, name, results, seen);
      continue;
    }
    if (!name.startsWith("Adobe Premiere Pro")) continue;

    const directPresets = await tryGetChildFolder(entry, "Presets");
    if (directPresets) await scanFolderForEpr(directPresets, name, results, seen);

    let bundleEntries;
    try {
      bundleEntries = await entry.getEntries();
    } catch (err) {
      continue;
    }
    for (const child of bundleEntries) {
      if (!child.isFolder || !child.name.endsWith(".app")) continue;
      const bundledPresets = await tryGetNestedFolder(child, ["Contents", "Presets"]);
      if (bundledPresets) {
        await scanFolderForEpr(bundledPresets, `${name} (bundled)`, results, seen);
      }
    }
  }
}

async function scanProgramFilesForPresets(results, seen) {
  const roots = [];
  if (process.env.ProgramFiles) roots.push(process.env.ProgramFiles);
  if (process.env["ProgramFiles(x86)"]) roots.push(process.env["ProgramFiles(x86)"]);

  for (const root of roots) {
    const adobe = await tryGetEntry(toFileUrl(`${root}/Adobe`));
    if (!adobe || !adobe.isFolder) continue;

    let entries;
    try {
      entries = await adobe.getEntries();
    } catch (err) {
      continue;
    }
    for (const entry of entries) {
      if (!entry.isFolder) continue;
      const name = entry.name;
      if (!name.startsWith("Adobe Media Encoder") && !name.startsWith("Adobe Premiere Pro")) continue;
      const presets = await tryGetChildFolder(entry, "Presets");
      if (presets) await scanFolderForEpr(presets, name, results, seen);
    }
  }
}

async function scanVersionedDocumentPresets(basePath, groupPrefix, results, seen) {
  const parent = await tryGetEntry(toFileUrl(basePath));
  if (!parent || !parent.isFolder) return;

  let entries;
  try {
    entries = await parent.getEntries();
  } catch (err) {
    return;
  }
  for (const entry of entries) {
    if (!entry.isFolder) continue;
    const presets = await tryGetChildFolder(entry, "Presets");
    if (presets) {
      await scanFolderForEpr(presets, `${groupPrefix} ${entry.name}`, results, seen);
    }
  }
}

async function discoverExportPresets() {
  const results = [];
  const seen = new Set();
  const home = os.homedir();
  const platform = os.platform();

  if (platform === "darwin") {
    await scanApplicationsForPresets(results, seen);
    await scanVersionedDocumentPresets(
      `${home}/Documents/Adobe/Adobe Media Encoder`,
      "AME Presets",
      results,
      seen
    );
    await scanVersionedDocumentPresets(
      `${home}/Documents/Adobe/Premiere Pro`,
      "Premiere Presets",
      results,
      seen
    );
    const common = await tryGetEntry("file:/Library/Application Support/Adobe/Common");
    if (common) await scanFolderForEpr(common, "Adobe Common", results, seen);
  } else if (platform === "win32") {
    await scanProgramFilesForPresets(results, seen);
    await scanVersionedDocumentPresets(
      `${home}/Documents/Adobe/Adobe Media Encoder`,
      "AME Presets",
      results,
      seen
    );
    await scanVersionedDocumentPresets(
      `${home}/Documents/Adobe/Premiere Pro`,
      "Premiere Presets",
      results,
      seen
    );
  }

  results.sort((a, b) => {
    const group = a.group.localeCompare(b.group);
    if (group !== 0) return group;
    return a.name.localeCompare(b.name);
  });
  return results;
}

function groupPresetsBySource(presets) {
  const groups = new Map();
  presets.forEach((preset) => {
    if (!groups.has(preset.group)) groups.set(preset.group, []);
    groups.get(preset.group).push(preset);
  });
  return groups;
}

function renderPresetDropdown(keepPath = presetPath) {
  const select = document.getElementById("presetSelect");
  const hint = document.getElementById("presetHint");
  if (!select) return;

  const previous = keepPath || select.value || "";
  select.innerHTML = "";

  const defaultOption = document.createElement("option");
  defaultOption.value = "";
  defaultOption.textContent = "Sequence default (current export settings)";
  select.appendChild(defaultOption);

  const groups = groupPresetsBySource(exportPresets);
  groups.forEach((items, groupLabel) => {
    if (groupLabel === "Custom") return;
    const optgroup = document.createElement("optgroup");
    optgroup.label = groupLabel;
    items.forEach((preset) => {
      const option = document.createElement("option");
      option.value = preset.path;
      option.textContent = preset.name;
      optgroup.appendChild(option);
    });
    select.appendChild(optgroup);
  });

  const customPresets = exportPresets.filter((p) => p.group === "Custom");
  if (customPresets.length > 0) {
    const customGroup = document.createElement("optgroup");
    customGroup.label = "Custom";
    customPresets.forEach((preset) => {
      const option = document.createElement("option");
      option.value = preset.path;
      option.textContent = preset.name;
      customGroup.appendChild(option);
    });
    select.appendChild(customGroup);
  }

  if (previous && Array.from(select.options).some((o) => o.value === previous)) {
    select.value = previous;
  } else {
    select.value = "";
    presetPath = null;
  }

  select.disabled = isLoadingPresets;
  if (hint) {
    hint.textContent = exportPresets.length
      ? `${exportPresets.length} preset(s) found — choose one or use sequence default.`
      : "No .epr presets found. Use Browse custom or sequence default.";
  }
}

function addCustomPreset(path) {
  const name = path.split(/[/\\]/).pop().replace(/\.epr$/i, "");
  const existing = exportPresets.find((p) => p.path === path);
  if (!existing) {
    exportPresets.push({ path, name, group: "Custom" });
    exportPresets.sort((a, b) => {
      if (a.group === "Custom" && b.group !== "Custom") return 1;
      if (b.group === "Custom" && a.group !== "Custom") return -1;
      return a.name.localeCompare(b.name);
    });
  }
}

async function applyPresetSelection(path) {
  presetPath = path || null;
  await syncExtensionFromPreset(presetPath);
}

async function loadExportPresets() {
  if (isLoadingPresets) return;
  isLoadingPresets = true;

  const select = document.getElementById("presetSelect");
  const hint = document.getElementById("presetHint");
  const refreshBtn = document.getElementById("refreshPresetsBtn");
  if (select) select.disabled = true;
  if (refreshBtn) refreshBtn.disabled = true;
  if (hint) hint.textContent = "Loading presets from Premiere Pro / Media Encoder…";

  const keepPath = presetPath;
  const customOnly = exportPresets.filter((p) => p.group === "Custom");

  try {
    if (IS_DEMO) {
      exportPresets = [...window.__TRACK_RENDER_DEMO__.MOCK_PRESETS];
      customOnly.forEach((preset) => {
        if (!exportPresets.some((p) => p.path === preset.path)) {
          exportPresets.push(preset);
        }
      });
      renderPresetDropdown(keepPath);
      presetPath = document.getElementById("presetSelect").value || null;
      if (presetPath) await syncExtensionFromPreset(presetPath);
      return;
    }

    const discovered = await discoverExportPresets();
    exportPresets = [...discovered];
    customOnly.forEach((preset) => {
      if (!exportPresets.some((p) => p.path === preset.path)) {
        exportPresets.push(preset);
      }
    });
    renderPresetDropdown(keepPath);
    presetPath = document.getElementById("presetSelect").value || null;
    if (presetPath) await syncExtensionFromPreset(presetPath);
  } catch (err) {
    console.error("Preset discovery failed:", err);
    exportPresets = [...customOnly];
    renderPresetDropdown(keepPath);
    if (hint) {
      hint.textContent = `Could not load presets: ${err.message || err}. Use Browse custom or sequence default.`;
    }
  } finally {
    isLoadingPresets = false;
    if (select) select.disabled = false;
    if (refreshBtn) refreshBtn.disabled = false;
  }
}

async function syncExtensionFromPreset(path) {
  const extInput = document.getElementById("outputExt");
  const extHint = document.getElementById("extHint");
  if (!path || !sequence) {
    if (extHint) {
      extHint.textContent = "Set manually to match your preset container (e.g. mov, wav).";
    }
    return;
  }
  try {
    const ext = await ppro.EncoderManager.getExportFileExtension(sequence, path);
    if (ext) {
      extInput.value = sanitizeExtension(ext);
      if (extHint) {
        extHint.textContent = `Auto-detected "${extInput.value}" from the selected preset.`;
      }
      return;
    }
  } catch (err) {
    console.warn("Could not read extension from preset:", err);
  }
  if (extHint) {
    extHint.textContent = "Could not read extension from preset — set it manually.";
  }
}

// Maps the chosen destination radio to the EncoderManager.exportSequence
// "exportType" argument. IMMEDIATELY renders inside Premiere itself.
// QUEUE_TO_AME hands the job to Adobe Media Encoder's queue instead of
// rendering in-process. Adobe's documented enum is QUEUE_TO_AME (not
// QUEUE_IN_AME); we fall back to the legacy name if an older build exposes it.
function getExportType(destination) {
  const exportTypes = ppro.Constants.ExportType;
  if (destination === "ame") {
    return exportTypes.QUEUE_TO_AME || exportTypes.QUEUE_IN_AME;
  }
  return exportTypes.IMMEDIATELY;
}

function getSelectedDestination() {
  return document.getElementById("destAme").checked ? "ame" : "premiere";
}

async function renderSelected() {
  if (!sequence) {
    setStatus("Rescan the sequence first.", "err");
    return;
  }

  const selected = getSelectedTracks();
  if (selected.length === 0) {
    setStatus("Select at least one track.", "err");
    return;
  }

  const baseName = document.getElementById("baseName").value.trim() || "export";
  const separateFiles = document.getElementById("separateFiles").checked;
  const outputFolder = outputFolderPath || document.getElementById("outputFolder").value.trim();
  const outputExt = document.getElementById("outputExt").value;
  const destination = getSelectedDestination();
  const exportType = getExportType(destination);

  if (!outputFolder) {
    setStatus("Choose an output folder first.", "err");
    return;
  }

  if (!exportType) {
    setStatus("Export destination is not supported in this Premiere version.", "err");
    return;
  }

  const renderBtn = document.getElementById("renderBtn");
  renderBtn.disabled = true;
  renderBtn.textContent = destination === "ame" ? "Queuing…" : "Rendering…";

  const destLabel = getDestinationLabel(destination);
  const succeeded = [];
  const failed = []; // [{ name, error }]

  setRenderStatus(
    "started",
    "Render started",
    `${destLabel} · ${selected.length} track(s) · ${separateFiles ? "separate files" : "combined file"}`
  );
  setStatus(`Render started via ${destLabel}…`, "busy");
  scrollToSection("renderStatus");

  try {
    const manager = await ppro.EncoderManager.getManager();

    if (destination === "ame" && !manager.isAMEInstalled) {
      const reason = "Adobe Media Encoder is not installed. Choose Premiere Pro or install AME.";
      setRenderStatus("failed", "Render failed", reason);
      setStatus(reason, "err");
      return;
    }

    await snapshotMuteState();

    const verb = destination === "ame" ? "Queuing" : "Rendering";

    if (separateFiles) {
      const total = selected.length;
      for (let i = 0; i < selected.length; i++) {
        const t = selected[i];
        const trackLabel = getTrackLabel(t);
        const jobName = `${trackLabel} (${t.name})`;
        const jobId = beginJobLogEntry(jobName, destination);
        const pct = Math.round((i / total) * 100);
        setProgress(pct, true);
        setRenderStatus(
          "started",
          "Render in progress",
          `${verb} ${jobName} (${i + 1}/${total}) via ${destLabel}`
        );
        setStatus(`${verb} ${trackLabel} (${t.name})… (${i + 1}/${total})`, "busy");
        try {
          await isolateTracks([t]);
          const outPath = buildOutputPath(outputFolder, baseName, buildTrackSuffix(t), outputExt);
          await runExport(manager, exportType, outPath);
          succeeded.push({ name: trackLabel, path: outPath });
          finishJobLogEntry(jobId, { ok: true, outPath });
        } catch (trackErr) {
          console.error(`Failed to render track "${trackLabel}":`, trackErr);
          const errMsg = trackErr.message || String(trackErr);
          failed.push({ name: trackLabel, error: errMsg });
          finishJobLogEntry(jobId, { ok: false, error: errMsg });
          setRenderStatus("failed", `${trackLabel} failed`, errMsg);
        }
      }
      setProgress(100, true);
    } else {
      const jobId = beginJobLogEntry("combined", destination);
      setProgress(30, true);
      setRenderStatus("started", "Render in progress", `${verb} combined export via ${destLabel}`);
      setStatus(`${verb} selected tracks…`, "busy");
      await isolateTracks(selected);
      const outPath = buildOutputPath(outputFolder, baseName, "combined", outputExt);
      try {
        setProgress(70, true);
        await runExport(manager, exportType, outPath);
        succeeded.push({ name: "combined", path: outPath });
        finishJobLogEntry(jobId, { ok: true, outPath });
        setProgress(100, true);
      } catch (combinedErr) {
        const errMsg = combinedErr.message || String(combinedErr);
        failed.push({ name: "combined", error: errMsg });
        finishJobLogEntry(jobId, { ok: false, error: combinedErr.message || String(combinedErr) });
        setRenderStatus("failed", "Render failed", errMsg);
      }
    }

    let statusTone = "ok";
    let statusMessage = "";
    let renderState = "done";
    let renderTitle = "Render complete";
    let renderDetail = "";

    if (failed.length === 0) {
      statusMessage =
        destination === "ame"
          ? `Sent ${succeeded.length} job(s) to Adobe Media Encoder. Switch to AME and press Start Queue (▶).`
          : `Render complete (${succeeded.length} file(s)). Check the output folder.`;
      renderDetail = succeeded.map((s) => `${s.name}: ${s.path}`).join("\n");
    } else if (succeeded.length === 0) {
      statusMessage = `All ${failed.length} render(s) failed.`;
      statusTone = "err";
      renderState = "failed";
      renderTitle = "Render failed";
      renderDetail = failed.map((f) => `${f.name}: ${f.error}`).join("\n");
    } else {
      statusMessage = `${succeeded.length} succeeded, ${failed.length} failed.`;
      statusTone = "warn";
      renderState = "failed";
      renderTitle = "Render finished with errors";
      renderDetail =
        "Succeeded:\n" + succeeded.map((s) => `${s.name}: ${s.path}`).join("\n") +
        "\n\nFailed:\n" + failed.map((f) => `${f.name}: ${f.error}`).join("\n");
    }

    const restoreErrors = await restoreMuteState();
    if (restoreErrors > 0) {
      const restoreNote = `${restoreErrors} timeline mute state(s) could not be restored.`;
      statusMessage += ` Warning: ${restoreNote}`;
      renderDetail += (renderDetail ? "\n\n" : "") + restoreNote;
      if (statusTone === "ok") statusTone = "warn";
    }

    setRenderStatus(renderState, renderTitle, renderDetail);
    setStatus(statusMessage, statusTone);
  } catch (err) {
    const restoreErrors = await restoreMuteState();
    const errMsg = err.message || String(err);
    let detail = errMsg;
    if (restoreErrors > 0) {
      detail += `\n\n${restoreErrors} mute state(s) could not be restored.`;
    }
    setRenderStatus("failed", "Render failed", detail);
    setStatus(`Render failed: ${errMsg}`, "err");
  } finally {
    setProgress(0, false);
    renderBtn.textContent = "Render armed tracks";
    updateRenderButtonState();
  }
}

entrypoints.setup({
  panels: {
    trackRenderPanel: {
      show() {
        loadSequence();
      },
    },
  },
});

window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("refreshBtn").addEventListener("click", loadSequence);
  document.getElementById("selectAllBtn").addEventListener("click", () => setAllTracksChecked(true));
  document.getElementById("selectNoneBtn").addEventListener("click", () => setAllTracksChecked(false));
  document.getElementById("chooseFolderBtn").addEventListener("click", async () => {
    await chooseOutputFolder();
  });
  document.getElementById("presetSelect").addEventListener("change", async () => {
    const path = document.getElementById("presetSelect").value || null;
    await applyPresetSelection(path);
  });
  document.getElementById("refreshPresetsBtn").addEventListener("click", loadExportPresets);
  document.getElementById("browsePresetBtn").addEventListener("click", async () => {
    const path = await choosePresetFile();
    if (!path) return;
    addCustomPreset(path);
    renderPresetDropdown(path);
    document.getElementById("presetSelect").value = path;
    await applyPresetSelection(path);
  });
  const destHint = document.getElementById("destHint");
  const onDestinationChange = () => updateDestinationUI(true);
  document.getElementById("destPremiere").addEventListener("change", onDestinationChange);
  document.getElementById("destAme").addEventListener("change", onDestinationChange);
  updateDestinationUI(false);
  updateReadinessPanel(false, 0, false);
  document.getElementById("renderBtn").addEventListener("click", renderSelected);
  document.getElementById("baseName").addEventListener("input", updateRenderButtonState);
  document.getElementById("outputExt").addEventListener("input", updateRenderButtonState);
  loadSequence();
});
