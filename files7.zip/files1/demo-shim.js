// Browser demo shim — loaded before index.js when ?demo=1 is in the URL.
// Provides mock Premiere / UXP modules so index.js runs unchanged in the browser.

(function () {
  const params = new URLSearchParams(location.search);
  if (params.get("demo") !== "1") return;

  document.documentElement.classList.add("demo-mode");

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function createMockTrack(name, clipCount) {
    let muted = false;
    return {
      name,
      async isMuted() {
        return muted;
      },
      async setMute(value) {
        muted = Boolean(value);
      },
      async getTrackItems() {
        return new Array(clipCount);
      },
    };
  }

  const mockVideoDefs = [
    { name: "A-Roll Interview", clipCount: 12 },
    { name: "B-Roll Cutaways", clipCount: 28 },
    { name: "GFX Lower Thirds", clipCount: 6 },
  ];
  const mockAudioDefs = [
    { name: "Dialogue Mix", clipCount: 12 },
    { name: "Music Bed", clipCount: 3 },
    { name: "SFX & Ambience", clipCount: 19 },
  ];

  const mockVideoTracks = mockVideoDefs.map((d) => createMockTrack(d.name, d.clipCount));
  const mockAudioTracks = mockAudioDefs.map((d) => createMockTrack(d.name, d.clipCount));

  const mockSequence = {
    async getVideoTrackCount() {
      return mockVideoTracks.length;
    },
    async getVideoTrack(i) {
      return mockVideoTracks[i];
    },
    async getAudioTrackCount() {
      return mockAudioTracks.length;
    },
    async getAudioTrack(i) {
      return mockAudioTracks[i];
    },
  };

  const mockProject = {
    async getActiveSequence() {
      return mockSequence;
    },
  };

  const MOCK_PRESETS = [
    { path: "demo:h264", name: "H.264 — Match Source - High bitrate", group: "Adobe Media Encoder" },
    { path: "demo:prores", name: "Apple ProRes 422 HQ", group: "Adobe Media Encoder" },
    { path: "demo:wav", name: "Uncompressed WAV 48kHz", group: "Premiere Pro" },
  ];

  const PRESET_EXTENSIONS = {
    "demo:h264": "mp4",
    "demo:prores": "mov",
    "demo:wav": "wav",
  };

  const mockEncoderManager = {
    isAMEInstalled: true,
    async exportSequence() {
      await sleep(700);
      return true;
    },
  };

  window.__TRACK_RENDER_DEMO__ = {
    MOCK_PRESETS,
    PRESET_EXTENSIONS,
    ppro: {
      Project: {
        async getActiveProject() {
          await sleep(400);
          return mockProject;
        },
      },
      EncoderManager: {
        async getManager() {
          return mockEncoderManager;
        },
        async getExportFileExtension(_sequence, presetPath) {
          return PRESET_EXTENSIONS[presetPath] || null;
        },
      },
      Constants: {
        ExportType: {
          IMMEDIATELY: "IMMEDIATELY",
          QUEUE_TO_AME: "QUEUE_TO_AME",
        },
      },
    },
    uxp: {
      storage: {
        domains: { userDocuments: "userDocuments" },
        localFileSystem: {
          async getFolder() {
            return { nativePath: "/Users/demo/Documents/TrackRender/Exports" };
          },
          async getFileForOpening() {
            return { nativePath: "/Users/demo/Documents/Presets/Apple_ProRes_422_HQ.epr" };
          },
          async getEntryWithUrl() {
            return null;
          },
        },
      },
      entrypoints: {
        setup() {},
      },
    },
    os: {
      homedir() {
        return "/Users/demo";
      },
      platform() {
        return "darwin";
      },
    },
  };
})();
