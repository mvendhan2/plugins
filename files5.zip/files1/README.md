# Track Render Panel

A UXP plugin for Premiere Pro: lists every video/audio track in the active
sequence with clip counts, lets you select which tracks to render, and
exports them (one combined file, or one file per track) to a folder you
choose.

## Setup

1. Open Premiere Pro, go to **Settings > Plugins**, enable **Developer mode**,
   restart Premiere.
2. Open the **UXP Developer Tool** (from Creative Cloud desktop app, or
   Premiere > Plugins > Development > UXP Developer Tool).
3. Click **Add Plugin**, select this folder's `manifest.json`.
4. Click **Load** (or **Load & Watch** to auto-reload on file changes).
5. In Premiere: **Window > UXP Plugins > Track Render Panel**.

Before distributing this beyond your own machine, change the `id` in
`manifest.json` to your own unique identifier (e.g. `com.yourcompany.trackrenderpanel`).

## UI design

The panel is styled as a mixing-console channel strip rather than a generic
settings form, since the subject matter is literally multiple tracks being
selected and routed:

- Each track row has a **tally light** (the small dot) that glows amber when
  selected for render — like a record-arm indicator — instead of a plain
  checkbox.
- **V/A chips** and clip counts use a monospace face, like a console's
  digital readout, to separate "data" from "labels."
- **Render destination** is two deck-style selector buttons (amber top edge
  for Premiere, teal for AME) instead of radio buttons, so the active
  destination is visually obvious at a glance.
- The **Activity** log (job history) only appears once a job has actually
  been submitted, to avoid showing an empty section by default.

## How it works

- **Scan**: on open (and via "Rescan sequence"), the panel reads
  `sequence.getVideoTrackCount()` / `getVideoTrack(i)` and the audio
  equivalents, then `track.getTrackItems()` for each to show a clip count.
- **Select**: check the tracks you want in the output.
- **Isolate**: before exporting, every *other* track gets muted via
  `track.setMute(true)`; your selected tracks are unmuted. Original mute
  states are restored after the render finishes (success or failure).
- **Preset**: optionally browse to an `.epr` preset file to pin down exact
  render settings (codec, resolution, bitrate, etc.). If you leave it blank,
  the sequence's current export settings are used — same as before.
- **Output extension**: set explicitly (default `mp4`) and must match your
  preset's actual container — it is *not* auto-detected from the preset
  file. Picking a ProRes or audio-only preset with the extension still set
  to `mp4` will misname the file even though the encode itself is correct.
- **Destination**: choose **Premiere Pro** (renders immediately, in-process)
  or **Adobe Media Encoder** (the job is handed to AME's queue and rendered
  there). Both destinations get the same preset, extension, output path, and
  isolated track selection — see "Verifying render settings are preserved"
  below.
- **Render**: `EncoderManager.exportSequence(sequence, exportType, outputFile, presetFile)`
  is called once per track if "separate files" is checked, or once for the
  whole selection if not. `exportType` is `Constants.ExportType.IMMEDIATELY`
  for Premiere or `Constants.ExportType.QUEUE_IN_AME` for AME. In separate-files
  mode, each track is rendered independently — if one fails, the rest still
  run, and the final status reports how many succeeded vs. failed.
- **Job log**: every job attempt (success or failure, either destination)
  appends a row to a persistent log under the status line, with a
  timestamp and the output path (or error). This exists because **the
  panel never brings Adobe Media Encoder to the front or auto-starts its
  queue** — clicking render with AME selected only adds the job to AME's
  queue in the background. The job log is the only confirmation inside the
  panel itself that something was actually submitted; to confirm the job
  is genuinely in AME and to render it, you still need to switch to AME
  manually and check its Queue panel, then press Start Queue (▶) there.

## Manual QA checklist (run inside Premiere — this can't be unit tested outside the app)

This plugin only runs inside Premiere Pro's UXP host, so the steps below need
to be run there. Suggested pass criteria for each:

1. **Track selection correctness**
   - Uncheck all but one video track, render. Confirm the output file
     contains only that track's content (others appear black/silent).
   - Re-check all tracks, render combined. Confirm all selected
     tracks appear in the single output.
   - Cancel mid-render (if possible) and reopen the panel — confirm mute
     states on the timeline match what they were before you rendered
     (the `finally` block in `renderSelected` should have restored them).

2. **Filenames and output location**
   - Set a custom base name and output folder, render with "separate files"
     checked. Confirm each file is named `<baseName>_<trackName>.mp4` and
     lands in the chosen folder.
   - Repeat with "separate files" unchecked — confirm a single
     `<baseName>_combined.mp4` is produced.
   - Use a track name containing characters like `/` or `:` — confirm
     `sanitizeFileName` strips them and no path errors occur.

3. **Render settings preserved — Premiere destination**
   - Pick an `.epr` preset with a distinctive setting (e.g. a specific
     resolution or bitrate). Render to Premiere. Inspect the output file's
     properties and confirm they match the preset, not the sequence default.
   - Clear the preset field, render again. Confirm the output now matches
     the sequence's current export settings instead.

4. **Render settings preserved — AME destination**
   - Same two preset scenarios as above, but with "Adobe Media Encoder"
     selected. Confirm the queued job in AME shows the correct preset
     applied (check the job's settings in AME's queue panel) before letting
     it render, then confirm the rendered file matches.
   - Confirm the AME queue entry uses the same output filename/path the
     panel displayed, and that only the selected tracks are present in the
     queued job (since track isolation happens via mute before the job is
     handed off).

5. **Behavioral parity between destinations**
   - Render the same track selection once to Premiere and once to AME with
     the same preset and output name (different folders to avoid overwrite).
     Compare the two resulting files — they should match in resolution,
     codec, bitrate, and content (same tracks visible/audible).

If `Constants.ExportType.QUEUE_IN_AME` doesn't exist in your installed
Premiere version's type definitions, check `npm install -D @adobe/premierepro`
for the correct enum member name and update `getExportType()` in `index.js`
accordingly — the API surface for this enum has shifted across Premiere
versions.

## Bugs found and fixed during static testing

These were caught by code-tracing and dry-running the pure logic outside
Premiere (since the plugin itself can only run inside the app):

- **Hardcoded `.mp4` extension.** Previously every output file was named
  `.mp4` regardless of preset, so a ProRes or audio-only preset would
  produce a correctly-encoded file with the wrong extension. Fixed by
  adding an explicit "Output file extension" field — note this still isn't
  auto-detected from the preset, so set it to match manually.
- **One failed track silently aborted the rest of the batch.** In "separate
  files" mode, an error on track 2 of 4 used to stop tracks 3–4 from
  rendering at all, with no record of what succeeded. Fixed: each track now
  renders independently inside its own try/catch, and the final status
  reports a success/failure count (e.g. "3 succeeded, 1 failed
  (V2). See console for details.").

## Known limitations

- **Track-level only.** Premiere's API exposes mute/unmute per *track*, not
  per *clip*. If you need to export one specific cut on a track while
  excluding others on the same track, this version can't isolate that —
  you'd need to duplicate the sequence in memory and remove the unwanted
  clips on the copy before exporting it, which is a heavier addition (happy
  to build that next if you need it).
- **Uses current export settings.** The `exportSequence` call here omits a
  preset file, so it renders with whatever export settings are already
  applied to the sequence. Pass a `.epr` path as the fourth argument once
  you've decided which presets you want exposed in the panel.
- **API surface is still evolving.** Method names here (`getVideoTrackCount`,
  `getTrackItems`, `EncoderManager.getManager()`, etc.) match Adobe's
  documented `@adobe/premierepro` type definitions as of mid-2026. Install
  the package (`npm install -D @adobe/premierepro`) in your dev environment
  for autocomplete and to catch any drift if Adobe changes signatures in a
  future Premiere release.

## Suggested next steps

- Add a checkbox to remove the AME job from the queue automatically once
  rendering completes there, via the `exportSequence` `removeUponCompletion`
  argument.
- Persist the last-used output folder, file name, and preset path between
  sessions using `localFileSystem.createPersistentToken()`.
- Surface AME queue/render progress in the panel (currently the panel just
  shows "Sent to Adobe Media Encoder queue." and can't report when AME
  actually finishes, since that happens out-of-process).
