#!/usr/bin/env node
/**
 * Static + DOM-mock tests for Track Render Panel.
 * Run: node test-plugin.js
 * Full render/UXP APIs require Premiere Pro — these tests cover logic and wiring.
 */

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
    console.log(`  ✓ ${message}`);
  } else {
    failed++;
    console.error(`  ✗ ${message}`);
  }
}

function assertEqual(actual, expected, message) {
  assert(actual === expected, `${message} (expected "${expected}", got "${actual}")`);
}

// --- Pure logic (mirrors index.js) ---
function sanitizeFileName(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, "_");
}

function sanitizeExtension(ext) {
  const cleaned = String(ext || "mp4").trim().replace(/^\./, "").replace(/[^a-zA-Z0-9]/g, "");
  return cleaned || "mp4";
}

function buildOutputPath(folder, baseName, suffix, ext) {
  const name = sanitizeFileName(`${baseName}_${suffix}`);
  return `${folder}/${name}.${sanitizeExtension(ext)}`;
}

function getTrackKey(kind, index) {
  return `${kind}:${index}`;
}

function getTrackLabel(t) {
  return (t.type === "video" ? "V" : "A") + (t.index + 1);
}

function buildTrackSuffix(t) {
  return sanitizeFileName(`${getTrackLabel(t)}_${t.name}`);
}

function getDestinationLabel(destination) {
  return destination === "ame" ? "Media Encoder" : "Premiere Pro";
}

function getExportTypeMock(destination, exportTypes) {
  if (destination === "ame") {
    return exportTypes.QUEUE_TO_AME || exportTypes.QUEUE_IN_AME;
  }
  return exportTypes.IMMEDIATELY;
}

function getEntryNativePath(entry) {
  if (!entry) return null;
  if (entry.nativePath) return entry.nativePath;
  if (entry.url) {
    const url = String(entry.url);
    if (url.startsWith("file:")) {
      let p = url.replace(/^file:/, "");
      if (p.startsWith("//")) p = p.slice(2);
      try {
        p = decodeURIComponent(p);
      } catch (err) {
        // keep raw
      }
      return p;
    }
  }
  return null;
}

function toFileUrl(nativePath) {
  const normalized = String(nativePath).replace(/\\/g, "/");
  if (normalized.startsWith("/")) {
    return `file:${normalized}`;
  }
  return `file:/${normalized}`;
}

// --- Tests ---
console.log("\n=== Manifest ===");
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));
assert(manifest.manifestVersion === 5, "manifestVersion is 5");
assert(manifest.host && manifest.host.app === "premierepro", "host is premierepro");
assert(manifest.entrypoints && manifest.entrypoints[0].id === "trackRenderPanel", "panel id trackRenderPanel");
assert(manifest.main === "index.html", "main entry is index.html");
assert(
  manifest.requiredPermissions.localFileSystem === "request",
  "localFileSystem permission is request (folder picker)"
);

console.log("\n=== File integrity ===");
assert(fs.existsSync(path.join(ROOT, "index.html")), "index.html exists");
assert(fs.existsSync(path.join(ROOT, "index.js")), "index.js exists");
const js = fs.readFileSync(path.join(ROOT, "index.js"), "utf8");
assert(!js.includes("getFolderForOpening"), "no deprecated getFolderForOpening()");
assert(js.includes("localFileSystem.getFolder"), "uses getFolder() for browse");
assert(js.includes("QUEUE_TO_AME"), "uses QUEUE_TO_AME export type");
assert(js.includes("exportSequence(") && js.includes("true\n  )"), "passes exportFull true via runExport");

console.log("\n=== HTML / JS DOM wiring ===");
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const htmlIds = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
const jsIds = [...js.matchAll(/getElementById\("([^"]+)"\)/g)].map((m) => m[1]);
const uniqueJsIds = [...new Set(jsIds)];
const missing = uniqueJsIds.filter((id) => !htmlIds.includes(id));
assert(missing.length === 0, `all JS getElementById targets exist in HTML (${missing.join(", ") || "none missing"})`);

const requiredButtons = [
  "refreshBtn", "selectAllBtn", "selectNoneBtn", "chooseFolderBtn",
  "refreshPresetsBtn", "browsePresetBtn", "renderBtn", "destPremiere", "destAme",
];
requiredButtons.forEach((id) => assert(htmlIds.includes(id), `button/input #${id} in HTML`));

console.log("\n=== Path / filename logic ===");
assertEqual(
  buildOutputPath("/out", "export", "V1_Music", "mp4"),
  "/out/export_V1_Music.mp4",
  "buildOutputPath basic"
);
assertEqual(
  buildOutputPath("/out", "test", buildTrackSuffix({ type: "video", index: 0, name: "Music" }), "mov"),
  "/out/test_V1_Music.mov",
  "unique track suffix"
);
assertEqual(
  buildTrackSuffix({ type: "audio", index: 0, name: "Music" }),
  "A1_Music",
  "audio track suffix"
);
assertEqual(
  buildTrackSuffix({ type: "video", index: 1, name: "Music" }),
  "V2_Music",
  "duplicate names get unique suffixes"
);
assertEqual(sanitizeExtension(""), "mp4", "empty extension defaults mp4");
assertEqual(sanitizeExtension(".wav"), "wav", "strips leading dot");
assertEqual(sanitizeFileName("bad/name:test"), "bad_name_test", "sanitizes illegal chars");

console.log("\n=== Track selection keys ===");
assertEqual(getTrackKey("video", 2), "video:2", "track key format");
const sel = new Set(["video:0", "audio:1"]);
assert(sel.has(getTrackKey("video", 0)), "selection set lookup works");
assert(!sel.has(getTrackKey("video", 1)), "unselected track not in set");

console.log("\n=== Destination labels ===");
assertEqual(getDestinationLabel("ame"), "Media Encoder", "AME label");
assertEqual(getDestinationLabel("premiere"), "Premiere Pro", "Premiere label");
const types = { QUEUE_TO_AME: "q", IMMEDIATELY: "i" };
assertEqual(getExportTypeMock("ame", types), "q", "AME export type");
assertEqual(getExportTypeMock("premiere", types), "i", "Premiere export type");
const legacy = { QUEUE_IN_AME: "legacy", IMMEDIATELY: "i" };
assertEqual(getExportTypeMock("ame", legacy), "legacy", "falls back to QUEUE_IN_AME");

console.log("\n=== Native path helpers ===");
assertEqual(
  getEntryNativePath({ nativePath: "/Users/test/Out" }),
  "/Users/test/Out",
  "nativePath direct"
);
assertEqual(
  getEntryNativePath({ url: "file:/Users/test/Out" }),
  "/Users/test/Out",
  "file URL decode"
);
assertEqual(toFileUrl("/Users/a/b"), "file:/Users/a/b", "unix file URL");
assertEqual(toFileUrl("C:\\Users\\a"), "file:/C:/Users/a", "windows file URL");

console.log("\n=== DOM mock: render button state ===");
function createMockDom() {
  const store = {
    outputFolder: { value: "" },
    renderBtn: { disabled: true, title: "" },
    folderHint: { textContent: "", style: { color: "" } },
  };
  const videoTracks = [{ index: 0 }, { index: 1 }];
  const audioTracks = [{ index: 0 }];
  let sequence = { id: 1 };
  let outputFolderPath = "";

  global.document = {
    getElementById(id) {
      if (id === "outputFolder") return store.outputFolder;
      if (id === "renderBtn") return store.renderBtn;
      if (id === "folderHint") return store.folderHint;
      return null;
    },
    querySelectorAll(sel) {
      if (sel === ".track-check") {
        return [
          { checked: true, dataset: { kind: "video", index: "0" } },
          { checked: false, dataset: { kind: "video", index: "1" } },
        ];
      }
      return [];
    },
  };

  global.getSelectedTracks = function mockGetSelectedTracks() {
    if (!sequence) return [];
    return [{ type: "video", index: 0, track: {}, name: "V1", clipCount: 1 }];
  };

  function updateRenderButtonState() {
    const renderBtn = document.getElementById("renderBtn");
    const folderHint = document.getElementById("folderHint");
    if (!renderBtn) return;
    const selectedCount = getSelectedTracks().length;
    const hasFolder = Boolean(outputFolderPath || document.getElementById("outputFolder").value.trim());
    const ready = Boolean(sequence) && selectedCount > 0 && hasFolder;
    renderBtn.disabled = !ready;
    renderBtn.title = !sequence
      ? "Rescan the sequence first"
      : selectedCount === 0
        ? "Arm at least one track"
        : !hasFolder
          ? "Choose an output folder"
          : "Start render";
    if (folderHint) {
      folderHint.textContent = hasFolder ? "Output folder selected." : "Click Browse…";
    }
  }

  return {
    store,
    updateRenderButtonState,
    setSequence(v) { sequence = v; },
    setFolder(p) {
      outputFolderPath = p;
      store.outputFolder.value = p;
    },
  };
}

const dom = createMockDom();
dom.updateRenderButtonState();
assert(dom.store.renderBtn.disabled === true, "render disabled without folder");
assert(dom.store.renderBtn.title.includes("folder"), "tooltip asks for folder");

dom.setFolder("/tmp/renders");
dom.updateRenderButtonState();
assert(dom.store.renderBtn.disabled === false, "render enabled with sequence, tracks, folder");

dom.setSequence(null);
dom.updateRenderButtonState();
assert(dom.store.renderBtn.disabled === true, "render disabled without sequence");

console.log("\n=== DOM mock: destination UI ===");
let destAmeChecked = false;
const badge = { textContent: "", className: "" };
const destHintEl = { textContent: "" };
global.document = {
  getElementById(id) {
    if (id === "destBadge") return badge;
    if (id === "destHint") return destHintEl;
    if (id === "destAme") return { checked: destAmeChecked };
    return null;
  },
  querySelector(sel) {
    return { classList: { add() {}, remove() {} } };
  },
  querySelectorAll() {
    return [{ classList: { remove() {} } }];
  },
};
global.getSelectedDestination = () => (destAmeChecked ? "ame" : "premiere");
global.scrollToSection = () => {};

function updateDestinationUIMock(scroll) {
  const destination = getSelectedDestination();
  const isAme = destination === "ame";
  badge.textContent = getDestinationLabel(destination);
  badge.className = isAme ? "dest-ame" : "dest-premiere";
  destHintEl.textContent = isAme ? "AME selected" : "Premiere selected";
  return { scroll };
}

let r = updateDestinationUIMock(false);
assert(badge.textContent === "Premiere Pro", "default destination Premiere");
destAmeChecked = true;
updateDestinationUIMock(true);
assert(badge.textContent === "Media Encoder", "switch to AME updates badge");
assert(destHintEl.textContent === "AME selected", "AME hint updates");

console.log("\n=== DOM mock: render status ===");
const renderPanel = { className: "", classList: { add() {}, remove() {} } };
const titleEl = { textContent: "" };
const detailEl = { textContent: "" };
global.document.getElementById = (id) => {
  if (id === "renderStatus") return renderPanel;
  if (id === "renderStatusTitle") return titleEl;
  if (id === "renderStatusDetail") return detailEl;
  return null;
};

function setRenderStatus(state, title, detail) {
  const panel = document.getElementById("renderStatus");
  const t = document.getElementById("renderStatusTitle");
  const d = document.getElementById("renderStatusDetail");
  if (!state) return;
  t.textContent = title || "";
  d.textContent = detail || "";
  panel.lastState = state;
}

setRenderStatus("started", "Render started", "Premiere Pro · 2 tracks");
assert(titleEl.textContent === "Render started", "render status title set");
assert(detailEl.textContent.includes("Premiere Pro"), "render status detail set");
setRenderStatus("failed", "Render failed", "Export was rejected");
assert(titleEl.textContent === "Render failed", "failure title shown");

// cleanup globals
delete global.document;
delete global.getSelectedTracks;
delete global.getSelectedDestination;
delete global.scrollToSection;

console.log("\n=== Summary ===");
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
if (failed > 0) {
  process.exit(1);
}
console.log("\nAll automated tests passed.");
console.log("Manual tests still required in Premiere Pro (folder picker, export, AME queue).\n");
