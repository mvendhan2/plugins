// Track Render Panel — index.js
//
// Notes on the API calls used below:
// - require("premierepro") gives the Premiere DOM API (Project, Sequence, tracks, EncoderManager).
// - require("uxp").storage gives the file-system picker used for the output folder.
// - Track listing uses sequence.getVideoTrackCount()/getVideoTrack(i) and the audio equivalents,
//   which is the documented pattern in Adobe's @adobe/premierepro type definitions.
// - "Selecting" a track for render is implemented by muting every other track, exporting,
//   then restoring the original mute states. Premiere's API does not expose per-clip
//   enable/disable, only per-track mute — see the README for the workaround if you need
//   clip-level (not just track-level) selection.
// - Verify method names against your installed Premiere version's type declarations
//   (npm install -D @adobe/premierepro) since the UXP API surface is still evolving.

const ppro = require("premierepro");
const uxpStorage = require("uxp").storage;
const localFileSystem = uxpStorage.localFileSystem;
const entrypoints = require("uxp").entrypoints;

let project = null;
let sequence = null;
let videoTracks = []; // { track, index, name, type, clipCount }
let audioTracks = [];
let originalMuteState = []; // [{ track, muted }]
let presetPath = null; // selected .epr path, or null = use sequence's current settings

function setStatus(message) {
  const el = document.getElementById("status");
  if (el) el.textContent = message;
}

// Adds one row to the persistent job log so the user has a record of what
// was actually submitted — important for the AME destination, where no
// window comes to the front and the panel's one-line status message is the
// only other feedback. Each entry stays visible until the panel reloads.
function addJobLogEntry({ ok, name, destination, outPath, error }) {
  document.getElementById("activitySection").style.display = "block";
  const log = document.getElementById("jobLog");
  log.classList.add("visible");
  const entry = document.createElement("div");
  entry.className = "job-entry " + (ok ? "ok" : "err");
  const time = new Date().toLocaleTimeString();
  const destLabel = destination === "ame" ? "AME queue" : "Premiere render";
  const line1 = document.createElement("div");
  line1.className = "job-line1";
  line1.innerHTML =
    '<span class="job-name">' + escapeHtml(name) + " — " + escapeHtml(destLabel) + '</span>' +
    '<span class="job-time">' + escapeHtml(time) + '</span>';
  entry.appendChild(line1);
  const pathLine = document.createElement("div");
  pathLine.className = "job-path";
  pathLine.textContent = ok ? outPath : `Failed: ${error}`;
  entry.appendChild(pathLine);
  log.insertBefore(entry, log.firstChild); // newest first
}

async function loadSequence() {
  setStatus("Scanning sequence…");
  try {
    project = await ppro.Project.getActiveProject();
    if (!project) {
      setStatus("No active project open in Premiere.");
      return;
    }
    sequence = await project.getActiveSequence();
    if (!sequence) {
      setStatus("No active sequence. Open a sequence in the timeline.");
      return;
    }

    videoTracks = [];
    audioTracks = [];

    const videoTrackCount = await sequence.getVideoTrackCount();
    for (let i = 0; i < videoTrackCount; i++) {
      const track = await sequence.getVideoTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      videoTracks.push({
        track,
        index: i,
        name: track.name || `V${i + 1}`,
        type: "video",
        clipCount: items ? items.length : 0,
      });
    }

    const audioTrackCount = await sequence.getAudioTrackCount();
    for (let i = 0; i < audioTrackCount; i++) {
      const track = await sequence.getAudioTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      audioTracks.push({
        track,
        index: i,
        name: track.name || `A${i + 1}`,
        type: "audio",
        clipCount: items ? items.length : 0,
      });
    }

    renderTrackList();
    setStatus(`Found ${videoTracks.length} video and ${audioTracks.length} audio track(s).`);
  } catch (err) {
    setStatus(`Scan failed: ${err.message || err}`);
  }
}

function renderTrackList() {
  const list = document.getElementById("trackList");
  list.innerHTML = "";
  const all = [...videoTracks, ...audioTracks];
  if (all.length === 0) {
    list.innerHTML = '<div class="channel-empty">No tracks found. Open a sequence and rescan.</div>';
    return;
  }
  all.forEach((t) => {
    const row = document.createElement("div");
    row.className = "channel-row";
    const idLabel = t.type === "video" ? "V" + (t.index + 1) : "A" + (t.index + 1);
    const idClass = t.type === "video" ? "v" : "a";
    row.innerHTML =
      '<label>' +
        '<input type="checkbox" class="track-check tally-input" data-kind="' + t.type + '" data-index="' + t.index + '" checked />' +
        '<span class="tally"></span>' +
        '<span class="channel-id ' + idClass + '">' + idLabel + '</span>' +
        '<span class="channel-name">' + escapeHtml(t.name) + '</span>' +
        '<span class="channel-count">' + t.clipCount + (t.clipCount === 1 ? ' clip' : ' clips') + '</span>' +
      '</label>';
    list.appendChild(row);
  });
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function getSelectedTracks() {
  const checks = document.querySelectorAll(".track-check");
  const selected = [];
  checks.forEach((c) => {
    if (!c.checked) return;
    const kind = c.dataset.kind;
    const index = parseInt(c.dataset.index, 10);
    const source = kind === "video" ? videoTracks : audioTracks;
    const found = source.find((t) => t.index === index);
    if (found) selected.push(found);
  });
  return selected;
}

async function snapshotMuteState() {
  originalMuteState = [];
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    const muted = await t.track.isMuted();
    originalMuteState.push({ track: t.track, muted });
  }
}

async function restoreMuteState() {
  for (const entry of originalMuteState) {
    try {
      await entry.track.setMute(entry.muted);
    } catch (err) {
      console.error("Failed to restore mute state:", err);
    }
  }
}

// Mutes every track except the ones in keepTracks.
async function isolateTracks(keepTracks) {
  const keepSet = new Set(keepTracks.map((t) => t.track));
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    await t.track.setMute(!keepSet.has(t.track));
  }
}

function sanitizeFileName(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, "_");
}

function sanitizeExtension(ext) {
  const cleaned = String(ext || "mp4").trim().replace(/^\./, "").replace(/[^a-zA-Z0-9]/g, "");
  return cleaned || "mp4";
}

function buildOutputPath(folder, baseName, suffix, ext) {
  const name = sanitizeFileName(`${baseName}_${suffix}`);
  return `${folder}/${name}.${sanitizeExtension(ext)}`;
}

async function chooseOutputFolder() {
  try {
    const folder = await localFileSystem.getFolderForOpening();
    if (!folder) return null;
    return folder.nativePath;
  } catch (err) {
    setStatus(`Folder selection failed: ${err.message || err}`);
    return null;
  }
}

async function choosePresetFile() {
  try {
    const file = await localFileSystem.getFileForOpening({
      types: ["epr"],
    });
    if (!file) return null;
    return file.nativePath;
  } catch (err) {
    setStatus(`Preset selection failed: ${err.message || err}`);
    return null;
  }
}

// Maps the chosen destination radio to the EncoderManager.exportSequence
// "exportType" argument. IMMEDIATELY renders inside Premiere itself.
// QUEUE_IN_AME hands the job to Adobe Media Encoder's queue instead of
// rendering in-process. Both names match Adobe's documented
// @adobe/premierepro Constants.ExportType enum as of mid-2026 — if your
// installed Premiere version uses different naming, check the type defs
// (npm install -D @adobe/premierepro) and update this map.
function getExportType(destination) {
  if (destination === "ame") {
    return ppro.Constants.ExportType.QUEUE_IN_AME;
  }
  return ppro.Constants.ExportType.IMMEDIATELY;
}

function getSelectedDestination() {
  return document.getElementById("destAme").checked ? "ame" : "premiere";
}

async function renderSelected() {
  if (!sequence) {
    setStatus("Rescan the sequence first.");
    return;
  }

  const selected = getSelectedTracks();
  if (selected.length === 0) {
    setStatus("Select at least one track.");
    return;
  }

  const baseName = document.getElementById("baseName").value.trim() || "export";
  const separateFiles = document.getElementById("separateFiles").checked;
  const outputFolder = document.getElementById("outputFolder").value;
  const outputExt = document.getElementById("outputExt").value;
  const destination = getSelectedDestination();
  const exportType = getExportType(destination);

  if (!outputFolder) {
    setStatus("Choose an output folder first.");
    return;
  }

  const renderBtn = document.getElementById("renderBtn");
  renderBtn.disabled = true;

  const succeeded = [];
  const failed = []; // [{ name, error }]

  try {
    const manager = await ppro.EncoderManager.getManager();
    await snapshotMuteState();

    const verb = destination === "ame" ? "Queuing" : "Rendering";

    if (separateFiles) {
      for (const t of selected) {
        setStatus(`${verb} ${t.name}… (${succeeded.length + failed.length + 1}/${selected.length})`);
        try {
          await isolateTracks([t]);
          const outPath = buildOutputPath(outputFolder, baseName, t.name, outputExt);
          // exportSequence(sequence, exportType, outputFile, presetFile, exportFull)
          // presetPath is passed through unchanged for both destinations so the
          // same render settings (resolution, codec, bitrate, etc.) are applied
          // whether the job runs in Premiere or is queued to AME. If no preset
          // was chosen, this is undefined and Premiere falls back to the
          // sequence's current export settings — same as before.
          await manager.exportSequence(sequence, exportType, outPath, presetPath || undefined);
          succeeded.push(t.name);
          addJobLogEntry({ ok: true, name: t.name, destination, outPath });
        } catch (trackErr) {
          // One track failing should not stop the rest of the batch — record
          // it and continue so the remaining selected tracks still get a
          // chance to render.
          console.error(`Failed to render track "${t.name}":`, trackErr);
          const errMsg = trackErr.message || String(trackErr);
          failed.push({ name: t.name, error: errMsg });
          addJobLogEntry({ ok: false, name: t.name, destination, error: errMsg });
        }
      }
    } else {
      setStatus(`${verb} selected tracks…`);
      await isolateTracks(selected);
      const outPath = buildOutputPath(outputFolder, baseName, "combined", outputExt);
      try {
        await manager.exportSequence(sequence, exportType, outPath, presetPath || undefined);
        succeeded.push("combined");
        addJobLogEntry({ ok: true, name: "combined", destination, outPath });
      } catch (combinedErr) {
        const errMsg = combinedErr.message || String(combinedErr);
        failed.push({ name: "combined", error: errMsg });
        addJobLogEntry({ ok: false, name: "combined", destination, error: errMsg });
      }
    }

    if (failed.length === 0) {
      setStatus(
        destination === "ame"
          ? `Sent ${succeeded.length} job(s) to Adobe Media Encoder. This panel does NOT open AME — switch to it manually and check the Queue panel to confirm the job(s) appear, then press Start Queue (▶) there to render.`
          : `Render complete (${succeeded.length} file(s)). Check the output folder to confirm.`
      );
    } else if (succeeded.length === 0) {
      setStatus(`All ${failed.length} render(s) failed. See the job log below and console for details.`);
    } else {
      setStatus(
        `${succeeded.length} succeeded, ${failed.length} failed ` +
        `(${failed.map((f) => f.name).join(", ")}). See the job log below for details.`
      );
    }
  } catch (err) {
    setStatus(`Render failed: ${err.message || err}`);
  } finally {
    // Mute state must be restored regardless of destination or whether
    // individual tracks failed. For AME jobs this happens immediately after
    // queuing (not after AME finishes rendering), since isolation only needs
    // to hold long enough for Premiere to capture the sequence state being
    // handed off.
    await restoreMuteState();
    renderBtn.disabled = false;
  }
}

entrypoints.setup({
  panels: {
    trackRenderPanel: {
      show() {
        loadSequence();
      },
    },
  },
});

window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("refreshBtn").addEventListener("click", loadSequence);
  document.getElementById("chooseFolderBtn").addEventListener("click", async () => {
    const path = await chooseOutputFolder();
    if (path) document.getElementById("outputFolder").value = path;
  });
  document.getElementById("choosePresetBtn").addEventListener("click", async () => {
    const path = await choosePresetFile();
    if (path) {
      presetPath = path;
      document.getElementById("presetPath").value = path;
    }
  });
  document.getElementById("clearPresetBtn").addEventListener("click", () => {
    presetPath = null;
    document.getElementById("presetPath").value = "";
  });
  const destHint = document.getElementById("destHint");
  const updateDestHint = () => {
    destHint.textContent =
      getSelectedDestination() === "ame"
        ? "Adds the job to AME's queue — does NOT switch to or open AME, and does NOT start rendering automatically. Open AME yourself to confirm and start it."
        : "Renders immediately inside Premiere Pro.";
  };
  document.getElementById("destPremiere").addEventListener("change", updateDestHint);
  document.getElementById("destAme").addEventListener("change", updateDestHint);
  document.getElementById("renderBtn").addEventListener("click", renderSelected);
  loadSequence();
});
