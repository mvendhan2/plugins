# Track Render Panel

A UXP plugin for Premiere Pro: lists every video/audio track in the active
sequence with clip counts, lets you select which tracks to render, and
exports them (one combined file, or one file per track) to a folder you
choose.

## Setup

1. Open Premiere Pro, go to **Settings > Plugins**, enable **Developer mode**,
   restart Premiere.
2. Open the **UXP Developer Tool** (from Creative Cloud desktop app, or
   Premiere > Plugins > Development > UXP Developer Tool).
3. Click **Add Plugin**, select this folder's `manifest.json`.
4. Click **Load** (or **Load & Watch** to auto-reload on file changes).
5. In Premiere: **Window > UXP Plugins > Track Render Panel**.

Before distributing this beyond your own machine, change the `id` in
`manifest.json` to your own unique identifier (e.g. `com.yourcompany.trackrenderpanel`).

## How it works

- **Scan**: on open (and via "Rescan sequence"), the panel reads
  `sequence.getVideoTrackCount()` / `getVideoTrack(i)` and the audio
  equivalents, then `track.getTrackItems()` for each to show a clip count.
- **Select**: check the tracks you want in the output.
- **Isolate**: before exporting, every *other* track gets muted via
  `track.setMute(true)`; your selected tracks are unmuted. Original mute
  states are restored after the render finishes (success or failure).
- **Render**: `EncoderManager.exportSequence(sequence, exportType, outputFile)`
  is called once per track if "separate files" is checked, or once for the
  whole selection if not.

## Known limitations

- **Track-level only.** Premiere's API exposes mute/unmute per *track*, not
  per *clip*. If you need to export one specific cut on a track while
  excluding others on the same track, this version can't isolate that —
  you'd need to duplicate the sequence in memory and remove the unwanted
  clips on the copy before exporting it, which is a heavier addition (happy
  to build that next if you need it).
- **Uses current export settings.** The `exportSequence` call here omits a
  preset file, so it renders with whatever export settings are already
  applied to the sequence. Pass a `.epr` path as the fourth argument once
  you've decided which presets you want exposed in the panel.
- **API surface is still evolving.** Method names here (`getVideoTrackCount`,
  `getTrackItems`, `EncoderManager.getManager()`, etc.) match Adobe's
  documented `@adobe/premierepro` type definitions as of mid-2026. Install
  the package (`npm install -D @adobe/premierepro`) in your dev environment
  for autocomplete and to catch any drift if Adobe changes signatures in a
  future Premiere release.

## Suggested next steps

- Add preset (`.epr`) selection to the dropdown instead of hardcoding `.mp4`.
- Add a checkbox to queue to Adobe Media Encoder instead of rendering
  immediately in Premiere (swap the `ExportType` constant).
- Persist the last-used output folder and file name between sessions using
  `localFileSystem.createPersistentToken()`.
