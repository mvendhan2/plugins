// Track Render Panel — index.js
//
// Notes on the API calls used below:
// - require("premierepro") gives the Premiere DOM API (Project, Sequence, tracks, EncoderManager).
// - require("uxp").storage gives the file-system picker used for the output folder.
// - Track listing uses sequence.getVideoTrackCount()/getVideoTrack(i) and the audio equivalents,
//   which is the documented pattern in Adobe's @adobe/premierepro type definitions.
// - "Selecting" a track for render is implemented by muting every other track, exporting,
//   then restoring the original mute states. Premiere's API does not expose per-clip
//   enable/disable, only per-track mute — see the README for the workaround if you need
//   clip-level (not just track-level) selection.
// - Verify method names against your installed Premiere version's type declarations
//   (npm install -D @adobe/premierepro) since the UXP API surface is still evolving.

const ppro = require("premierepro");
const uxpStorage = require("uxp").storage;
const localFileSystem = uxpStorage.localFileSystem;
const entrypoints = require("uxp").entrypoints;

let project = null;
let sequence = null;
let videoTracks = []; // { track, index, name, type, clipCount }
let audioTracks = [];
let originalMuteState = []; // [{ track, muted }]

function setStatus(message) {
  const el = document.getElementById("status");
  if (el) el.textContent = message;
}

async function loadSequence() {
  setStatus("Scanning sequence…");
  try {
    project = await ppro.Project.getActiveProject();
    if (!project) {
      setStatus("No active project open in Premiere.");
      return;
    }
    sequence = await project.getActiveSequence();
    if (!sequence) {
      setStatus("No active sequence. Open a sequence in the timeline.");
      return;
    }

    videoTracks = [];
    audioTracks = [];

    const videoTrackCount = await sequence.getVideoTrackCount();
    for (let i = 0; i < videoTrackCount; i++) {
      const track = await sequence.getVideoTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      videoTracks.push({
        track,
        index: i,
        name: track.name || `V${i + 1}`,
        type: "video",
        clipCount: items ? items.length : 0,
      });
    }

    const audioTrackCount = await sequence.getAudioTrackCount();
    for (let i = 0; i < audioTrackCount; i++) {
      const track = await sequence.getAudioTrack(i);
      const items = await track.getTrackItems(1 /* Clip */, false);
      audioTracks.push({
        track,
        index: i,
        name: track.name || `A${i + 1}`,
        type: "audio",
        clipCount: items ? items.length : 0,
      });
    }

    renderTrackList();
    setStatus(`Found ${videoTracks.length} video and ${audioTracks.length} audio track(s).`);
  } catch (err) {
    setStatus(`Scan failed: ${err.message || err}`);
  }
}

function renderTrackList() {
  const list = document.getElementById("trackList");
  list.innerHTML = "";
  const all = [...videoTracks, ...audioTracks];
  if (all.length === 0) {
    list.innerHTML = '<div class="track-row">No tracks found.</div>';
    return;
  }
  all.forEach((t) => {
    const row = document.createElement("div");
    row.className = "track-row";
    const label = t.type === "video" ? "V" : "A";
    row.innerHTML =
      '<label>' +
        '<input type="checkbox" class="track-check" data-kind="' + t.type + '" data-index="' + t.index + '" checked />' +
        '<span class="track-name">' + escapeHtml(t.name) + '</span>' +
        '<span class="track-meta">' + label + ' &middot; ' + t.clipCount + (t.clipCount === 1 ? ' clip' : ' clips') + '</span>' +
      '</label>';
    list.appendChild(row);
  });
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function getSelectedTracks() {
  const checks = document.querySelectorAll(".track-check");
  const selected = [];
  checks.forEach((c) => {
    if (!c.checked) return;
    const kind = c.dataset.kind;
    const index = parseInt(c.dataset.index, 10);
    const source = kind === "video" ? videoTracks : audioTracks;
    const found = source.find((t) => t.index === index);
    if (found) selected.push(found);
  });
  return selected;
}

async function snapshotMuteState() {
  originalMuteState = [];
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    const muted = await t.track.isMuted();
    originalMuteState.push({ track: t.track, muted });
  }
}

async function restoreMuteState() {
  for (const entry of originalMuteState) {
    try {
      await entry.track.setMute(entry.muted);
    } catch (err) {
      console.error("Failed to restore mute state:", err);
    }
  }
}

// Mutes every track except the ones in keepTracks.
async function isolateTracks(keepTracks) {
  const keepSet = new Set(keepTracks.map((t) => t.track));
  const all = [...videoTracks, ...audioTracks];
  for (const t of all) {
    await t.track.setMute(!keepSet.has(t.track));
  }
}

function sanitizeFileName(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, "_");
}

function buildOutputPath(folder, baseName, suffix) {
  const name = sanitizeFileName(`${baseName}_${suffix}`);
  return `${folder}/${name}.mp4`;
}

async function chooseOutputFolder() {
  try {
    const folder = await localFileSystem.getFolderForOpening();
    if (!folder) return null;
    return folder.nativePath;
  } catch (err) {
    setStatus(`Folder selection failed: ${err.message || err}`);
    return null;
  }
}

async function renderSelected() {
  if (!sequence) {
    setStatus("Rescan the sequence first.");
    return;
  }

  const selected = getSelectedTracks();
  if (selected.length === 0) {
    setStatus("Select at least one track.");
    return;
  }

  const baseName = document.getElementById("baseName").value.trim() || "export";
  const separateFiles = document.getElementById("separateFiles").checked;
  const outputFolder = document.getElementById("outputFolder").value;

  if (!outputFolder) {
    setStatus("Choose an output folder first.");
    return;
  }

  const renderBtn = document.getElementById("renderBtn");
  renderBtn.disabled = true;

  try {
    const manager = await ppro.EncoderManager.getManager();
    await snapshotMuteState();

    if (separateFiles) {
      for (const t of selected) {
        setStatus(`Rendering ${t.name}…`);
        await isolateTracks([t]);
        const outPath = buildOutputPath(outputFolder, baseName, t.name);
        // exportSequence(sequence, exportType, outputFile, presetFile, exportFull)
        // Omitting presetFile uses the sequence's current export settings.
        await manager.exportSequence(sequence, ppro.Constants.ExportType.IMMEDIATELY, outPath);
      }
    } else {
      setStatus("Rendering selected tracks…");
      await isolateTracks(selected);
      const outPath = buildOutputPath(outputFolder, baseName, "combined");
      await manager.exportSequence(sequence, ppro.Constants.ExportType.IMMEDIATELY, outPath);
    }

    setStatus("Render complete.");
  } catch (err) {
    setStatus(`Render failed: ${err.message || err}`);
  } finally {
    await restoreMuteState();
    renderBtn.disabled = false;
  }
}

entrypoints.setup({
  panels: {
    trackRenderPanel: {
      show() {
        loadSequence();
      },
    },
  },
});

window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("refreshBtn").addEventListener("click", loadSequence);
  document.getElementById("chooseFolderBtn").addEventListener("click", async () => {
    const path = await chooseOutputFolder();
    if (path) document.getElementById("outputFolder").value = path;
  });
  document.getElementById("renderBtn").addEventListener("click", renderSelected);
  loadSequence();
});
